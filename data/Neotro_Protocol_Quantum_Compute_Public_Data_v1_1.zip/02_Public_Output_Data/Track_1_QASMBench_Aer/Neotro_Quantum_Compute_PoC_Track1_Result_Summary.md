# Neotro Quantum Compute PoC Track 1 - Result Summary

Experiment ID: Neotro_Quantum_Compute_PoC_Track1_QASMBench_FakeBackend_Aer_v0_1
Run timestamp UTC: 2026-05-17T06:52:07Z
Backend: fake_manila
Shots per circuit: 2048

## Source verification
- QASMBench total qasm files: 252 (small 85, medium 47, large 120)
- MQT Bench extracted and retained as extension source: True

## Execution summary
- Selected circuits: 10
- Successful executions: 10
- Supplemental/error rows: 0

## Q-state aggregate
- Q0 Stable Reference: 2 (20.0%)
- Q1 Noise Watch: 2 (20.0%)
- Q2 Drift Review Candidate: 0 (0.0%)
- Q3 Execution Uncertainty Candidate: 6 (60.0%)
- Q4 Calibration Boundary Candidate: 0 (0.0%)
- QX Supplemental / Unavailable Layer: 0 (0.0%)

## Boundary
These results are observer-layer review-reference states only. They do not prove quantum advantage, error-correction improvement, QPU control, provider performance, or circuit optimization.