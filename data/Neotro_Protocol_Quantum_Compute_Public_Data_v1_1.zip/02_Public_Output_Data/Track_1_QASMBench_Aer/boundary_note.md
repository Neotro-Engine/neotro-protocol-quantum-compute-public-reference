# Public / Restricted Boundary Note

This Track 1 output package is public-data-only and observer-layer-only.

Allowed claims:
- Public QASMBench circuits can be loaded and represented as observation units.
- Public fake-backend/noise simulation can generate result-count distributions.
- Circuit complexity, backend/noise proxy fields, and distribution features can be mapped into Q-state review-reference outputs.
- Aggregate Q-state tables can support Neotro Quantum Compute observer-layer feasibility discussion.

Avoided claims:
- No quantum advantage claim.
- No QPU control claim.
- No quantum error-correction improvement claim.
- No provider replacement or performance comparison claim.
- No circuit optimization claim.
- No operational calibration authority claim.
- No private backend data or partner operational data used.
