# Track 1 - QASMBench + Aer Fake Backend Aggregate Package

This folder contains aggregate public-reference artifacts for the Track 1 reproducible simulator/noise observer run.

## Public contents
- Circuit/source inventory summaries
- Public observation-unit and feature-group descriptions
- Ideal/noisy result-count JSON outputs for the selected small-circuit run
- Aggregate Q-state distribution CSV/JSON
- Boundary note
- SHA256 manifest

## Boundary
This track does not require live QPU access for Track 1 and does not claim hardware performance, QPU control, circuit optimization, quantum advantage, or provider comparison.

Row-level assignment workbooks and assignment-rule reconstruction files are outside this public aggregate package.

## Q-state grammar note
Q2 label note: within the shared Q-state grammar, Track 1 uses a drift-review candidate label for simulator/noise-layer context; this is not an exact row-level assignment rule.
