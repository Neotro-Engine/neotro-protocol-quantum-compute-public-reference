# Neotro Quantum Compute PoC Track 2 — Quantinuum QV Report

## Executive summary
Track 2 successfully loaded the public Quantinuum Quantum Volume repository archive, inspected the data schema, and converted public hardware-result records into Q-state observer outputs.

## Source metadata
- Source: Quantinuum Hardware Quantum Volume Data
- Repository: https://github.com/Quantinuum/quantinuum-hardware-quantum-volume
- Download date: 2026-05-17
- Uploaded as split 7z archive pieces and reconstructed locally.

## Data schema inspection
The repository contains README.md, data/, notebooks/, qtm_qv/, requirements.txt, and setup.py. The data folder contains raw_results JSON files with heavy_ideal, heavy_outputs, qv_circs, qv_circs_nomeas, and raw_results fields, plus circuit-only JSON files for selected larger-n groups.

## Observation unit definition
The primary observation unit is one QV circuit trial / raw result distribution. File-level qubit/device groups are used for aggregate checks.

## Q-state distribution
- Q0 Stable Reference: 2445 (30.8556%)
- Q1 Result Watch: 2748 (34.6795%)
- Q3 Execution Uncertainty Candidate: 2330 (29.4043%)
- Q4 Boundary / High-Variance Candidate: 401 (5.0606%)

Single-class collapse check: no.

## Final judgment
Based on the Quantinuum public Quantum Volume dataset, Track 2 supports real public execution-record observer feasibility. The data can be organized into public observation units, public feature groups, and Q-state review outputs without requiring private QPU control, provider comparison, quantum advantage claims, or operational calibration authority.
