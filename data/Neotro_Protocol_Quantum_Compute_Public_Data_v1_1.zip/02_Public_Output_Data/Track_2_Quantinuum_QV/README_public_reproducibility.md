# Track 2 - Quantinuum QV Public Execution-Record Aggregate Package

This folder contains aggregate public-reference artifacts for the Track 2 public QV execution-record observer mapping.

## Public contents
- QV source/file inventory summaries
- Public observation-unit and feature-group descriptions
- Aggregate Q-state distribution CSV/JSON
- Public evidence summary
- Boundary note
- SHA256 manifest

## Boundary
This track is used only as a public execution-record observer-state summary. It does not claim Quantum Volume superiority, provider comparison, QPU control, circuit optimization, or performance verdicts.

Row-level Q-state assignment files, row-level observer-feature tables, and heavy-output row-level reconstruction paths are outside this public aggregate package.

## Q-state grammar note
Q2 label note: within the shared Q-state grammar, Track 2 uses a metadata-review candidate label for public QV record context; this is not an exact row-level assignment rule.
