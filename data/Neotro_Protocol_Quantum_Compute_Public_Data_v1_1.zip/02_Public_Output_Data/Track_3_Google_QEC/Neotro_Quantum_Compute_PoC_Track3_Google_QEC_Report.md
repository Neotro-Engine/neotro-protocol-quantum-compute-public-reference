# Neotro Quantum Compute PoC Track 3 — Google QEC Report

## Executive summary
Track 3 used the Google Quantum AI public QEC / surface-code experiment archive from Zenodo record 6804040. The public data loaded successfully and produced 522 decoder-prediction observation units across 131 experiment groups.

The Q-state grammar did not collapse into a single class. It produced the following public review-reference distribution:

- Q0 Stable Reference: 42 (8.05%)
- Q1 Syndrome Watch: 65 (12.45%)
- Q2 Decoder Review Candidate: 67 (12.84%)
- Q3 Execution / Syndrome Uncertainty Candidate: 258 (49.43%)
- Q4 Boundary / High-Correction Candidate: 90 (17.24%)

## Source metadata
- Source: Google Quantum AI public QEC / surface-code experiment data
- Zenodo: https://zenodo.org/records/6804040
- DOI: 10.5281/zenodo.6804040
- Download date: 2026-05-17
- License noted in user macro: Creative Commons Attribution 4.0 International

## Observation unit definition
Track 3 uses one decoder-prediction record within one experiment directory as the primary observation unit. The unit links a public experiment group, actual observable flip records, predicted observable flip records, and detection-event density proxies.

## Boundary preservation
This Track 3 PoC evaluates whether public QEC experiment records can be organized into non-invasive observer-layer review states. It does not claim quantum advantage, QPU control, decoder improvement, error-correction improvement, provider superiority, or operational calibration authority.

## Final judgment
Based on the Google Quantum AI public QEC dataset, Track 3 supports public QEC execution-record observer feasibility. The data can be organized into public observation units, public feature groups, and Q-state review outputs without requiring private QPU control, decoder improvement, quantum advantage claims, provider comparison, or operational calibration authority.
