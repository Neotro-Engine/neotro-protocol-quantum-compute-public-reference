# Track 3 - Google QEC Public Execution-Record Aggregate Package

This folder contains aggregate public-reference artifacts for the Track 3 Google QEC / decoder / correction observer mapping.

## Public contents
- QEC data/file inventory summaries
- Experiment-group, decoder/correction, and metadata-completeness summaries
- Aggregate Q-state distribution CSV/JSON
- Aggregate boundary summary only
- SHA256 manifest

## Boundary
This track is used only as a public QEC/decoder observer-state summary. It does not claim decoder improvement, QEC improvement, QPU control, calibration authority, hardware weakness, or performance verdicts.

Non-public record-level materials and implementation-sensitive observer materials are outside this public aggregate package.

Non-public record-level boundary materials are outside this public package; Track 3 boundary handling is retained only as an aggregate summary.

## Q-state grammar note
Q2 label note: within the shared Q-state grammar, Track 3 uses a decoder-review candidate label for QEC/decoder/correction-layer context; this is not a record-level implementation specification.
