# Neotro_Protocol_Quantum_Compute_Public_Data_v1_1

This aggregate-centered package contains the public-release evidence artifacts for **Quantum Compute Execution Observer-State Mapping using Public Quantum Records**.

Package filename: `Neotro_Protocol_Quantum_Compute_Public_Data_v1_1.zip`

The full public report PDF is distributed separately. This data ZIP intentionally keeps the full-report PDF outside the data package, and the DOCX editing source is not part of the public data package.

## Scope
This is a public-reference observer-layer package. It evaluates whether public quantum-computing execution records can be organized into non-invasive observer-state review outputs.

It does **not** claim quantum advantage, QPU control, circuit optimization, provider comparison, operational calibration authority, decoder improvement, error-correction improvement, or performance verdicts.

## Included material
- `01_Results_XLSX/` - aggregate-only Track 1, Track 2, and Track 3 result workbooks.
- `02_Public_Output_Data/` - selected aggregate CSV/JSON/MD outputs for each track.
- `03_Metadata/` - source registry, cross-track summary, boundary note, excluded-material note, package metadata, and package manifest.

## Public aggregate tracks

| Track | Canonical observation unit | Observation units | States present | QX | Role |
|---|---:|---:|---|---:|---|
| Track 1 | QASMBench circuit execution under Aer fake backend | 10 | Q0/Q1/Q3 | 0 | Public reproducible simulator/noise observer proof |
| Track 2 | Quantinuum QV public circuit-trial result record | 7,924 | Q0/Q1/Q3/Q4 | 0 | Real public QPU execution-record observer proof |
| Track 3 | Google QEC decoder-prediction record | 522 | Q0/Q1/Q2/Q3/Q4 | 0 | Real public QEC/decoder observer proof |


## Q-state grammar note
Q-state labels share a common public-reference grammar across tracks. Some labels are track-specialized to the data layer; for example, Q2 may appear as a drift-review, metadata-review, or decoder-review candidate depending on the track context. These labels are public review-reference meanings, not record-level implementation details or non-public operating logic.


## JSON structure note
Track-level `q_state_aggregate_summary.json` files use a common object wrapper for aggregate review-state summaries. The cross-track comparison file `03_Metadata/cross_track_q_state_summary.json` is also object-wrapped, with the comparison entries stored under `tracks` for GitHub/Zenodo readability.

## Aggregate-centered public release boundary
This public package supports:
- public data-source orientation
- observation-unit inventory
- aggregate Q-state distribution verification
- source registry review
- checksum-based package integrity review
- boundary-consistent review-priority interpretation

This public package excludes:
- non-public record-level materials
- non-public observer-feature materials
- non-public record-level boundary materials
- feature-value and Q-state pairings at individual observation-unit level
- non-public implementation materials and internal working tables
- non-public implementation or operating materials

## Verification
Use `03_Metadata/MANIFEST_SHA256.csv` to verify every included file in this aggregate-centered public data package.

Manifest note: package and track manifest files intentionally do not list themselves because self-hashing a manifest is self-referential. The manifest entries cover the other public files in their stated scope.

Track 3 boundary handling is represented only by an aggregate boundary summary; non-public record-level materials are outside the public data package.
