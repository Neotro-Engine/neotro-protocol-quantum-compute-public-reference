# Excluded Material Note

The public data ZIP is aggregate-centered. It intentionally excludes materials that are not required for public-reference aggregate verification or that may create threshold-like reconstruction paths.

Excluded from this public package:
- original raw ZIP/7z source archives
- large raw public dataset bodies repackaged from third-party repositories
- row-level Q-state assignment files
- row-level observer-feature tables
- row-level boundary-note tables or per-observation boundary notes
- feature-value and Q-state pairings at individual observation-unit level
- threshold-like reconstruction files and internal working tables
- internal dry-run or non-canonical comparison outputs
- private threshold/calibration notes or unpublished operating logic
- working scratch files and extraction intermediates

The package preserves public reproducibility at the aggregate evidence level through aggregate workbooks, aggregate CSV/JSON files, source inventories, README files, boundary notes, and SHA256 manifests.

Track 3 boundary handling is retained only as an aggregate boundary summary in the public package.
