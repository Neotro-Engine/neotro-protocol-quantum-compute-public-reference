# Excluded Material Note

The public data ZIP is aggregate-centered. It intentionally excludes materials that are not required for public-reference aggregate verification or that are outside the public-reference boundary.

Excluded from this public package:
- original raw ZIP/7z source archives
- large raw public dataset bodies repackaged from third-party repositories
- non-public record-level materials
- non-public observer-feature materials
- non-public record-level boundary materials
- feature-value and Q-state pairings at individual observation-unit level
- non-public implementation materials and internal working tables
- internal dry-run or non-canonical comparison outputs
- non-public implementation notes or unpublished operating materials
- working scratch files and extraction intermediates

The package preserves public reproducibility at the aggregate evidence level through aggregate workbooks, aggregate CSV/JSON files, source inventories, README files, boundary notes, and SHA256 manifests.

Track 3 boundary handling is retained only as an aggregate boundary summary in the public package.
