# Public Boundary Note

This package is scoped as public observer-layer reference material only.

Neotro Protocol is used here to organize public quantum records into observer-state review outputs. The package does not modify, control, optimize, replace, or evaluate the original quantum system, QPU workflow, decoder, provider pipeline, or source execution system.

Out of scope:
- quantum advantage claim
- QPU control or calibration authority
- provider superiority or provider comparison
- circuit optimization
- decoder improvement
- error-correction improvement
- operational deployment certification
- private backend or live account-gated execution data
- performance verdicts or source-system commands

Raw public source archives are not repackaged. Source locations and public roles are recorded in the source registry.
